Capes:
HDcape1.png = Normal cape
HDcape2.png = German Cape
HDcape3.png = USA Cape
HDcape4.png = England Cape
HDcape5.png = Brazil Cape
HDcape6.png = Spain Cape
HDcape7.png = Weed Cape


You can find the instructions here:
https://www.youtube.com/watch?v=HpP4Z15ntAU
